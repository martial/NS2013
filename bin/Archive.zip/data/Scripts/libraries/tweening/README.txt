Put this folder in your data/sketches folder.


Project @ http://quasipartikel.at/projects/processing-js-libs/Tween/