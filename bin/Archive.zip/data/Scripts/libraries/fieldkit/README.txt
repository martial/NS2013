

	FieldKit.js
	http://code.google.com/p/fieldkit
	
	JavaScript building blocks for interactive applications + animations 
	in the browser.
	
	Copyright (c) 2010 Marcus Wendt <marcus at field.io>
	
	see also: License.txt
	
	. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .  

	HISTORY
	
	FieldKit.js-01 (r305) - 19 January 2010
	
	Initial release!
	
	+ Package.js 
	  providing core Class-inheritance & logging functions
	  
	+ Math.js, Vec2.js, Vec3.js basic math classes
	
	+ Noise.js providing simplex (similar to perlin) noise methods
	
	+ Colour.js basic color class with rgb / hsv conversion methods 

	+ Sketch.js simple processing like framework for quick <canvas> based animation sketches
	
	+ Build script
	 
	